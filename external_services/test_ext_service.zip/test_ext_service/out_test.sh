echo "hello" > hello
cat hello
