# Cisco Spark

This is an example external service for Cisco CloudCenter. It will post a message into a Spark room of choice.

## Service Parameters
The service parameters are;
 * Authorization - This is user API token used by Spark for authorisation
 * roomId - The Spark room ID
 * proxy - Define the proxy to be used for communication to Spark
